# OJS 3.0 manual

Hjælp til publicering af tidsskrifter og enkeltnumre med Open Journal Systems.

Her gives en indledende oversigt over de enkelte trin i workflowet fra indsendelse til produktion samt uddybende baggrundsinformation om nogle af konfigurationsmulighederne. 

Hjælpelinket på de enkelte programsider åbner op til nyttig information for den aktuelle side.

En mere detaljeret gennemgang af programmet er tilgængeligt her: [Learning OJS 3.0](https://www.gitbook.com/book/pkp/ojs3/details).



