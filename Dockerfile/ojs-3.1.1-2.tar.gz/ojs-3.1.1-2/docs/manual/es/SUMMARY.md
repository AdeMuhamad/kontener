# Summary

* [Introducción](README.md)
* [Perfil de usuario](user-profile.md)
* [Autoría](authoring.md)
* [Revisión](reviewing.md)
* [Gestión de envíos](submissions.md)
* [Flujo de trabajo editorial](editorial-workflow.md)
   * [Envío](editorial-workflow/submission.md)
   * [Revisión](editorial-workflow/review.md)
   * [Edición](editorial-workflow/copyediting.md)
   * [Producción](editorial-workflow/production.md)
* [Gestión del número](issue-management.md)
* [Tareas](tasks.md)
* [Ajustes](settings.md)
* [Usuarios y roles](users-and-roles.md)
* [Herramientas](tools.md)
* [Administración](administration.md)

