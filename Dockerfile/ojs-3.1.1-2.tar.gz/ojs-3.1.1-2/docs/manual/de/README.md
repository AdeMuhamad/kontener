# OJS 3.0: Handbuch für Nutzerinnen und Nutzer

Dieses Handbuch wird Ihnen helfen, Zeitschriften und Ausgaben mit Open Journal Systems zu veröffentlichen.
