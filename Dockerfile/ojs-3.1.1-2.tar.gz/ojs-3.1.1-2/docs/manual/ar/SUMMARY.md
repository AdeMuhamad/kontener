﻿# الخلاصة

* [مقدمة](README.md)
* [الملف الشخصي للمستخدم](user-profile.md)
* [التأليف](authoring.md)
* [التحكيم](reviewing.md)
* [إدارة طلبات النشر](submissions.md)
* [مجريات التحرير](editorial-workflow.md)
   * [مرحلة تقديم طلب النشر](editorial-workflow/submission.md)
   * [مراحل التحكيم](editorial-workflow/review.md)
   * [التدقيق](editorial-workflow/copyediting.md)
   * [الإنتاج](editorial-workflow/production.md)
* [إدارة الأعداد](issue-management.md)
* [المهام](tasks.md)
* [الإعدادات](settings.md)
* [المستخدمون والأدوار](users-and-roles.md)
* [الأدوات](tools.md)
* [الإدارة](administration.md)

